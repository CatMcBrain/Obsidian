clear
a=0.1;
b=0.9; 
Du=1;
Dv=10;
u0 = a+b;
v0 = b/(a+b)^2;

% Jacobiano
J = [-1+2*u0*v0, u0^2; -2*u0*v0, -u0^2];
fprintf('Los autovalores son:');
display(eig(J)); % Autovalores
if real(eig(J)) < 0
    fprintf('Los valores reales son negativos.'); %foco
else
    fprintf('Los valores reales son positivos.');
end

% Evolución de las perturbaciones M(k)
kval = linspace(0,2,600);
eigM = 1:length(kval);

for i=1:length(kval)
    k=kval(i);
    M = J-[Du*k^2, 0; 0, Dv*k^2];
    eigM(i) = real(max(eig(M)));
end

hold on;
ind = find(eigM==max(eigM),1,'last'); % hallar último índice correspondiente del valor máximo
plot(kval, eigM); % relación de dispersión
text(0.6,0.2,sprintf('kmax = %f', kval(ind)));  % kmax en el que la dispersión es máxima
plot(kval(ind), eigM(ind),'o');
hold off;